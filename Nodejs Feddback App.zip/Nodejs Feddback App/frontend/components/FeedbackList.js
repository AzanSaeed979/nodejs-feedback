import React, { useEffect, useState } from 'react';
import axios from 'axios';

function FeedbackList({ refresh }) {
  const [feedbacks, setFeedbacks] = useState([]);

  useEffect(() => {
    const fetchFeedbacks = async () => {
      const res = await axios.get('http://localhost:5000/api/feedback');
      setFeedbacks(res.data);
    };
    fetchFeedbacks();
  }, [refresh]);

  return (
    <div>
      <h2>Feedbacks</h2>
      {feedbacks.map(fb => (
        <div key={fb._id} style={{ marginBottom: '10px', borderBottom: '1px solid gray' }}>
          <p><strong>{fb.name}</strong> ({fb.email})</p>
          <p>{fb.message}</p>
        </div>
      ))}
    </div>
  );
}

export default FeedbackList;
