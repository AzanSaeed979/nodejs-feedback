import React, { useState } from 'react';
import FeedbackForm from './components/FeedbackForm';
import FeedbackList from './components/FeedbackList';

function App() {
  const [refresh, setRefresh] = useState(false);
  const toggleRefresh = () => setRefresh(!refresh);

  return (
    <div>
      <h1>Feedback App</h1>
      <FeedbackForm onFeedbackSubmitted={toggleRefresh} />
      <FeedbackList refresh={refresh} />
    </div>
  );
}

export default App;
